import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Commands extends Thread {
    @Override
    public void run() {
        super.run();
        String number = "";
        String name = "";
        String path = "";
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String line = null;
        while (!Thread.interrupted()) {
            try {
                line = reader.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (line.equals(Command.start.getCom())) {
                Story.go();
            } else if (line.equals(Command.add_if_min.getCom())) {
                while (name.equals("")) {
                    System.out.println("Введите имя");
                    try {
                        name = reader.readLine();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                while (number.equals("")) {
                    System.out.println("Присвойте номер");
                    try {
                        number = reader.readLine();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                Prison.add_if_min(number, name);
            } else if (line.equals(Command.clear.getCom())) {
                Prison.clear();

            } else if (line.equals(Command._import.getCom())) {
                while (path.equals("")) {
                    System.out.println("Укажите адресс файла");
                    try {
                        path = reader.readLine();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                Prison._import(path);
            } else if (line.equals(Command.show.getCom())) {
                Prison.show();
            } else if (line.equals(Command.add.getCom())) {
                while (name.equals("")) {
                    System.out.println("Введите имя");
                    try {
                        name = reader.readLine();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                while (number.equals("")) {
                    System.out.println("Присвойте номер");
                    try {
                        number = reader.readLine();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                Prison.add(number, name);
                name="";
                number="";
            } else if (line.equals(Command.remove.getCom())) {
                while (name.equals("")) {
                    System.out.println("Введите имя");
                    try {
                        name = reader.readLine();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                Prison.remove(name);
            } else if (line.equals(Command.info.getCom())) {
                Prison.info();
            } else if (line.equals(Command.stop.getCom())) {
                try {
                    Story.end();
                    Thread.interrupted();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
    enum Command{
        start("start"),add_if_min("add_if_min"),clear("clear"),_import("import"),show("show"),add("add"),remove("remove"),info("info"),stop("stop");
        private String com;
        Command(String com) {
            this.com=com;
        }

        public String getCom() {
            return com;
        }
    }
