import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;

class Story extends Thread{
    static Boolean stat=false;
    public static void main(String[] args){
        System.out.println("Start!");



        new Commands().start();
        new Painter("Маркус");
        new Painter("Фиби");
        new Bird(50);
        new Caretaker("Хемль");

    }

    public static void go() {
        System.out.println("GO");
        stat=true;
    }

    public static boolean end() throws IOException {
        Prison.writeToFile();
        System.exit(0);
        return false;
    }
}